package com.oracle.demosjon.demojson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemojsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
